package io.github.fintrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FintrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
